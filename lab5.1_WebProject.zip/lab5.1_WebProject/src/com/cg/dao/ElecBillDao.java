package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.ElectricityBill;

public interface ElecBillDao
{
	public int addBillDetails(ElectricityBill elecBill) throws Exception;
	public int generateBillNumber() throws Exception;
	public ArrayList<Integer> getConsumerNo() throws Exception;
	public String getConsumerName(int consumerNumber) throws Exception;
}
